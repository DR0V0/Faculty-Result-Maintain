<?php
    session_start();
?>
<html>
    <head>
        <title>Manage The Section</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <?php
            if(isset($_SESSION['admin_id'])){
        ?>
            <div class="head">
                <div class="head_left_side">
                    <h1>Welcome MDH Sir!</h1>
                </div>
                <div class="head_right_side">
                    <table>
                        <tr>
                            <td>
                                <a href="all_sections.php">
                                    <figure>
                                        <img src="back.png" alt="Back" height="50" width="50">
                                    </figure>
                                </a>
                            </td>
                            <td>
                                <a href="sign_out.php">
                                    <figure>
                                        <img src="logout.png" alt="Sign Out" height="50" width="50">
                                    </figure>
                                </a>
                            </td>
                        </tr>
                    </table> 
                </div>
            </div>
            <div class="body">
                <?php
                    $conn = mysqli_connect("localhost","root","","mdh");
                    if($conn){
                        if(isset($_GET['section_id'])){
                            $section_id = $_GET['section_id'];
                            $my_second_qur = "SELECT * FROM classes_info WHERE id = '$section_id'";
                            $my_second_qur_insert = mysqli_query($conn,$my_second_qur);
                            $row_s = mysqli_fetch_array($my_second_qur_insert);
                            $section_name = $row_s['section_name'];
                            $my_first_qur = "SELECT * FROM ".$section_name;
                            $my_first_qur_insert = mysqli_query($conn,$my_first_qur);
                            if(mysqli_num_rows($my_first_qur_insert)>0){
                ?>
                            <table>
                                <tr>
                                    <th>Student ID</th>
                                    <th>QUIZ 1</th>
                                    <th>MID 1</th>
                                    <th>QUIZ 2</th>
                                    <th>MID 2</th>
                                    <th>QUIZ 3</th>
                                </tr>
                                <?php
                                    while($row = mysqli_fetch_array($my_first_qur_insert)){
                                ?>
                                    <tr>
                                        <td><?php echo $row['id'] ?></td>
                                        <td><?php echo $row['quiz1'] ?></td>
                                        <td><?php echo $row['mid1'] ?></td>
                                        <td><?php echo $row['quiz2'] ?></td>
                                        <td><?php echo $row['mid2'] ?></td>
                                        <td><?php echo $row['quiz3'] ?></td>
                                    </tr>
                                <?php
                                    }
                                ?>
                            </table>
                <?php
                            }
                            else{
                                echo("NO STUDENT IS ADDED! PLEASE ADD SOME ID.");
                            }
                        }
                        else{
                            echo("NO SECTION NAME FOUND!");
                        }
                    }
                    else{
                        echo("NOT CONNECTED!");
                    }
                ?>
            </div>
            
        <?php
            }
            else{
                header("Location:admin_login.php");
            }
        ?>
    </body>
</html>