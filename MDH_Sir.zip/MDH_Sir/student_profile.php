<?php
    session_start();
?>
<html>
    <head>
        <title>Student Profile</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <?php
            if(isset($_SESSION['student_id'])){
        ?>
            <div class="s_head">
                <div class="s_head_left_side">
                   <h1><?php echo($_SESSION['student_id']) ?></h1>
               </div>
               <div class="s_head_right_side">
                  <table>
                      <tr>
                          <td>
                            <a href="student_home_page.php">
                                <figure>
                                    <img src="back.png" alt="Back" height="50" width="50">
                                </figure>
                            </a>
                          </td>
                          <td>
                              <a href="student_sign_out.php">
                                <figure>
                                    <img src="logout.png" alt="Sign Out" height="50" width="50">
                                </figure>
                            </a>
                          </td>
                      </tr>
                  </table>
                   
               </div>
            </div>
            <div class="s_body">
                <?php
                $student_id = $_SESSION['student_id'];
                $conn = mysqli_connect("localhost","root","","mdh");
                    if($conn){
                        $my_first_qur = "SELECT * FROM student_info WHERE student_id = '$student_id'";
                        $my_first_qur_insert = mysqli_query($conn,$my_first_qur);
                        if(mysqli_num_rows($my_first_qur_insert)>0){
                            $row = mysqli_fetch_array($my_first_qur_insert);
        ?>
                            <table border="1">
                                <tr>
                                    <th>Student Name</th>
                                    <td><?php echo(ucwords($row['student_name'])); ?></td>
                                </tr>
                                <tr>
                                    <th>Student ID</th>
                                    <td><?php echo $row['student_id'] ?></td>
                                </tr>
                                <tr>
                                    <th>Email</th>
                                    <td><?php echo $row['student_email'] ?></td>
                                </tr>
                                <tr>
                                    <th>Contact Number</th>
                                    <td><?php echo $row['contact_number'] ?></td>
                                </tr>
                                <tr>
                                    <th>Semester</th>
                                    <td><?php echo(strtoupper($row['semester_name'])) ?></td>
                                </tr>
                                <tr>
                                    <th>Course Code</th>
                                    <td><?php echo (strtoupper($row['course_code'])); ?></td>
                                </tr>
                                <tr>
                                    <th>Section Number</th>
                                    <td><?php echo $row['section_number'] ?></td>
                                </tr>
                            </table>
        <?php
                        }
                        else{
                            echo("YOUR PROFILE NOT FOUND!");
                        }
                    }
                    else{
                        echo("NOT CONNECTED!");
                    }
        ?>
            
        <?php
            }
            else{
                header("Location:index.php");
            }
        ?>
            </div>
        
    </body>
</html>