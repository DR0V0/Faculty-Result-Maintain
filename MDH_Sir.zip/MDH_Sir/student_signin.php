<?php
    session_start();
?>
<html>
    <head>
        <title>Sign In</title>
    </head>
    <body>
       
       <?php
            
        $student_id = "";
        $password = "";
        
        if($_SERVER['REQUEST_METHOD'] == "POST"){
            $student_id = valid_the_input($_POST['student_id']);
            $password = valid_the_input($_POST['password']);
                if($student_id != null && $password != null){
                    $conn = mysqli_connect("localhost","root","","mdh");
                    if($conn){
                        $my_first_qur = "SELECT * FROM student_info WHERE student_id = '$student_id' AND password = '$password'";
                        $my_first_qur_insert = mysqli_query($conn,$my_first_qur);
                        
                        if(mysqli_num_rows($my_first_qur_insert)>0){
                            $_SESSION['student_id'] = $student_id;
                            header("Location:student_home_page.php");
                            
                        }
                        else{
                            echo("WRONG ID OR PASSWORD!");
                        }
                    }
                    else{
                        echo("NOT CONNECTED!");
                    }
                }
        }
            
        function valid_the_input($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        ?>
       
        <form method="POST" action="">
            Enter ID: <input type="text" name="student_id" placeholder="Enter ID"><br />
            Enter Password: <input type="password" name="password" placeholder="Enter Password"><br />
            <input type="submit" name="submit" value="Sign In" />
        </form>
    </body>
</html>