-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 24, 2018 at 08:38 AM
-- Server version: 10.1.31-MariaDB
-- PHP Version: 7.2.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mdh`
--

-- --------------------------------------------------------

--
-- Table structure for table `classes_info`
--

CREATE TABLE `classes_info` (
  `id` int(11) NOT NULL,
  `semester_name` varchar(20) NOT NULL,
  `course_code` varchar(20) NOT NULL,
  `section_number` int(11) NOT NULL,
  `section_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `classes_info`
--

INSERT INTO `classes_info` (`id`, `semester_name`, `course_code`, `section_number`, `section_name`) VALUES
(3, 'fall2018', 'cse480', 1, 'fall2018_cse480_1');

-- --------------------------------------------------------

--
-- Table structure for table `fall2018_cse480_1`
--

CREATE TABLE `fall2018_cse480_1` (
  `id` varchar(50) DEFAULT NULL,
  `mid1` varchar(50) DEFAULT NULL,
  `mid2` varchar(50) DEFAULT NULL,
  `final` varchar(50) DEFAULT NULL,
  `quiz1` varchar(50) DEFAULT NULL,
  `quiz2` varchar(50) DEFAULT NULL,
  `quiz3` varchar(50) DEFAULT NULL,
  `assignment1` varchar(50) DEFAULT NULL,
  `assignment2` varchar(50) DEFAULT NULL,
  `assignment3` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fall2018_cse480_1`
--

INSERT INTO `fall2018_cse480_1` (`id`, `mid1`, `mid2`, `final`, `quiz1`, `quiz2`, `quiz3`, `assignment1`, `assignment2`, `assignment3`) VALUES
('2015-1-60-129', '2', '4', NULL, '1', '3', '5', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `student_name` varchar(150) NOT NULL,
  `student_id` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `student_email` varchar(150) NOT NULL,
  `contact_number` varchar(30) NOT NULL,
  `semester_name` varchar(30) NOT NULL,
  `course_code` varchar(10) NOT NULL,
  `section_number` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`student_name`, `student_id`, `password`, `student_email`, `contact_number`, `semester_name`, `course_code`, `section_number`) VALUES
('Mah Dian Drovo', '2015-1-60-129', '1234', 'mahdian.drovo@gmail.com', '01676946820', 'fall2018', 'cse480', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `classes_info`
--
ALTER TABLE `classes_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `classes_info`
--
ALTER TABLE `classes_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
