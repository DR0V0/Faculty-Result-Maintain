<?php
    session_start();
?>
<html>
    <head>
        <title>
            Manage Sections
        </title>
        <link rel="stylesheet" type="text/css" href="style.css" />
        <script>
            function get_section_name(s_id){
                window.location = 'manage_the_section.php?section_id='+s_id;
            }
        </script>
    </head>
    <body>
       
        <?php
            if(isset($_SESSION['admin_id'])){
        ?>
            <div class="head">
                <div class="head_left_side">
                    <h1>Sir Here are the sections</h1>
                </div>
                <div class="head_right_side">
                    <table>
                        <tr>
                            <td>
                                <a href="admin_home_page.php">
                                    <figure>
                                        <img src="back.png" alt="Back" height="50" width="50">
                                    </figure>
                                </a>
                            </td>
                            <td>
                                <a href="sign_out.php">
                                    <figure>
                                        <img src="logout.png" alt="Sign Out" height="50" width="50">
                                    </figure>
                                </a>
                            </td>
                        </tr>
                    </table> 
                    </div>
            </div>
            <div class="body">
                <?php
                    $conn = mysqli_connect("localhost","root","","mdh");
                    if($conn){
                        $my_first_qur = "SELECT * FROM classes_info";
                        $my_first_qur_insert = mysqli_query($conn,$my_first_qur);
                        if(mysqli_num_rows($my_first_qur_insert)>0){
                            while($row = mysqli_fetch_array($my_first_qur_insert)){
                ?>
                                <a href="javascript:get_section_name(<?php echo $row['id'] ?>)">
                <?php
                                echo (strtoupper($row['course_code']));
                                echo("(");
                                echo ($row['section_number']);
                                echo(")");
                ?>
                                    </a>
                                    <br />
                <?php
                                
                            }
                        }
                        else{
                            echo("SORRY. THERE IS NO SECTION ADDED.");
                        }
                    }else{
                        echo("NOT CONNECTED!");
                    }
                ?>
            </div>
        <?php
            }
            else{
                header("Location:admin_login.php");
            }
        ?>
    </body>
</html>