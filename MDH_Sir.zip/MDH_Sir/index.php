<html>
    <head>
        <title>Home Page</title>
    </head>
    <body>
       <center>
           <div>
               <table>
                   <tr>
                       <td>
                           <a href="student_signin.php">
                               <figure>
                                  <img src="student_sign_in.png" alt="Student Sign Up" height="100" width="100">
                                  <figcaption>Sign In</figcaption>
                               </figure>
                           </a>
                       </td>
                       <td>
                           <a href="student_signup.php">
                               <figure>
                                  <img src="student_sign_up.png" alt="Student Sign Up" height="100" width="100">
                                  <figcaption>Sign Up</figcaption>
                               </figure>
                           </a>
                       </td>
                   </tr>
               </table>
           </div>
       </center>
    </body>
</html>