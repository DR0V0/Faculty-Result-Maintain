<?php
    session_start();
?>
<html>
    <head>
        <title>Student Result</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <?php
            if(isset($_SESSION['student_id'])){
                $student_id = $_SESSION['student_id'];
        ?>
            <div class="s_head">
                <div class="s_head_left_side">
                   <h1><?php echo($_SESSION['student_id']) ?></h1>
               </div>
               <div class="s_head_right_side">
                  <table>
                      <tr>
                          <td>
                            <a href="student_home_page.php">
                                <figure>
                                    <img src="back.png" alt="Back" height="50" width="50">
                                </figure>
                            </a>
                          </td>
                          <td>
                              <a href="student_sign_out.php">
                                <figure>
                                    <img src="logout.png" alt="Sign Out" height="50" width="50">
                                </figure>
                            </a>
                          </td>
                      </tr>
                  </table>
                   
               </div>
            </div>
            <div class="s_body">
                <?php
                    $conn = mysqli_connect("localhost","root","","mdh");
                    if($conn){
                        $my_first_qur = "SELECT * FROM student_info WHERE student_id = '$student_id'";
                        $my_first_qur_insert = mysqli_query($conn,$my_first_qur);
                        $row = mysqli_fetch_array($my_first_qur_insert);
                        
                        $semester_name = $row['semester_name'];
                        $course_code = $row['course_code'];
                        $section_number = $row['section_number'];
                        
                        
                        $section_name = "$semester_name"."_$course_code"."_$section_number";
                        
                        $my_second_qur = "SELECT * FROM ".$section_name;
                        $my_second_qur_insert = mysqli_query($conn,$my_second_qur);
                        
                        if($my_second_qur_insert){
                            $my_third_qur = "SELECT * FROM ".$section_name." WHERE id = '$student_id'";
                            $my_third_qur_insert = mysqli_query($conn,$my_third_qur);
                            $num = mysqli_num_rows($my_third_qur_insert);
                            if($num>0){
                                $row = mysqli_fetch_array($my_third_qur_insert);
                ?>
                        <table border="1">
                            <tr>
                                <th>QUIZ 01</th>
                                <td><?php echo $row['quiz1'] ?></td>
                            </tr>
                            <tr>
                                <th>MID 01</th>
                                <td><?php echo $row['mid1'] ?></td>
                            </tr>
                            <tr>
                                <th>QUIZ 02</th>
                                <td><?php echo $row['quiz2'] ?></td>
                            </tr>
                            <tr>
                                <th>MID 02</th>
                                <td><?php echo $row['mid2'] ?></td>
                            </tr>
                            <tr>
                                <th>QUIZ 03</th>
                                <td><?php echo $row['quiz3'] ?></td>
                            </tr>
                        </table>
                <?php
                            }
                            else{
                ?>
                                <img src="sad_face.png" alt="Sad Face" height="100" width="100">
                <?php
                                
                                echo("NO DATA FOUND! CONTACT WITH US.");
                            }
                        }
                        else{
                ?>
                            <img src="sad_face.png" alt="Sad Face" height="100" width="100">
                <?php
                            
                            echo("NO DATA FOUND! CONTACT WITH US.");
                        }
                    }
                    else{
                        echo("NOT CONNECTED!");
                    }
                ?>
            </div>
        <?php
            }
            else{
                header("Location:index.php");
            }
        ?>
    </body>
</html>