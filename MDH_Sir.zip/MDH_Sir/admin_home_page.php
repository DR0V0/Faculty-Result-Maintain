<?php
    session_start();
?>
<html>
    <head>
        <title>Admin Home Page</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <?php
            if(isset($_SESSION['admin_id'])){
        ?>
        <div class="head">
           <div class="head_left_side">
               <h1>Welcome MDH Sir!</h1>
           </div>
            <div class="head_right_side">
               <a href="sign_out.php">
                    <figure>
                        <img src="logout.png" alt="Sign Out" height="50" width="50">
                    </figure>
                </a>
           </div>
            
        </div>
        <div class="body">
           <table>
               <tr>
                   <td>
                        <a href="sign_up_section.php">
                            <figure>
                                <img src="add_section.png" alt="Add Section" height="100" width="100">
                                <figcaption>Add Section</figcaption>
                            </figure>
                        </a>
                   </td>
                   <td>
                        <a href="all_sections.php">
                            <figure>
                                <img src="manage_sections.png" alt="Manage Sections" height="100" width="100">
                                <figcaption>Manage Sections</figcaption>
                            </figure>
                        </a>
                   </td>
               </tr>
           </table>
            
        </div>
        <?php
            }
        else{
            header("Location:admin_login.php");
        }
        ?>
    </body>
</html>