<html>
    <head>
        <title>Sign Up</title>
    </head>
    <body>
       <?php
            
            $conn = mysqli_connect("localhost","root","","mdh");
        
            $name = "";
            $id = "";
            $password = "";
            $c_password = "";
            $course_code = "";
            $section_number = "";
            $email = "";
            $contact_number = "";
            $semester_name = "";
            
            if($_SERVER['REQUEST_METHOD'] == "POST"){
                $name = valid_the_input($_POST['name']);
                $id = valid_the_input($_POST['id']);
                $password = valid_the_input($_POST['password']);
                $c_password = valid_the_input($_POST['c_password']);
                $email = valid_the_input($_POST['email']);
                $contact_number = valid_the_input($_POST['contact_number']);
                $semester_name = valid_the_input($_POST['semester_name']);
                
                
                $course_code = valid_the_input($_POST['course_code']);
                $section_number = valid_the_input($_POST['section_number']);
                
                if(isset($_POST['submit'])){
                    if($name != "" && $id != "" && $password != "" && $c_password != "" && $course_code != "" && $section_number != "" && $semester_name != ""){
                        
                        $my_second_qur = "SELECT student_id FROM student_info WHERE student_id = '$id'";
                        $my_second_qur_insert = mysqli_query($conn,$my_second_qur);
                        
                        if($password != $c_password){
                            echo ("PASSWORD NOT MATCHED!");
                        }
                        else if(mysqli_num_rows($my_second_qur_insert)>0){
                            echo ("ID ALREADY REGISTERD!");
                        }
                        else{
                            if($conn){
                            $my_first_query = "INSERT INTO student_info(student_name,student_id,password,student_email,contact_number,semester_name,course_code,section_number) VALUES('$name','$id','$password','$email','$contact_number','$semester_name','$course_code','$section_number')";
                            $my_first_query_insert = mysqli_query($conn,$my_first_query);
                            if($my_first_query_insert){
                                header("Location:index.php");
                            }
                            else{
                                echo ("NOT INSERTED!");
                            }
                        }
                        else{
                            echo("NOT CONNECTED!");
                        }
                    
                }
            }
                }
                
                
                
            }
        
            
        
            function valid_the_input($data){
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
            
        ?>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            *Name: <input type="text" name="name" placeholder="Enter your name"><br />
            *ID: <input type="text" name="id" placeholder="Enter your ID"><br />
            *Password: <input type="password" name="password" placeholder="Enter password"><br />
            *Confirm Password: <input type="password" name="c_password" placeholder="Confirm password"><br />
            Email: <input type="text" name="email" placeholder="Enter your Email ID"><br />
            Contact Number: <input type="text" name="contact_number" placeholder="Enter your Contact number"><br />
            *Course Cose:
            <select name="semester_name">
                <option value="fall2018">FALL 2018</option>   
            </select><br />
            *Course Cose:
            <select name="course_code">
                <option value="cse101">CSE101</option>
                <option value="cse480">CSE480</option>    
            </select><br />
            *Section:
            <select name="section_number">
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="8">8</option>
                <option value="9">9</option>   
            </select><br /><br />
            <input type="submit" name="submit" value="Sign Up" />
        </form>
    </body>
</html>