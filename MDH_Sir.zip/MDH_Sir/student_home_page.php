<?php
    session_start();
?>
<html>
    <head>
        <title>Home Page</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <?php
            if(isset($_SESSION['student_id'])){
        ?>
        <div class="s_head">
            <div class="s_head_left_side">
               <h1>Welcome <?php echo($_SESSION['student_id']) ?>!</h1>
           </div>
           <div class="s_head_right_side">
               <a href="student_sign_out.php">
                    <figure>
                        <img src="logout.png" alt="Sign Out" height="50" width="50">
                    </figure>
                </a>
           </div>
        </div>
        <div class="s_body">
           <table>
               <tr>
                   <td>
                       <a href="student_profile.php">
                            <figure>
                                <img src="view_profile.jpg" alt="View Profile" height="100" width="100">
                                <figcaption>View Profile</figcaption>
                            </figure>
                        </a>
                   </td>
                   <td>
                       <a href="student_result.php">
                            <figure>
                                <img src="view_result.png" alt="View Profile" height="100" width="100">
                                <figcaption>View Profile</figcaption>
                            </figure>
                        </a>
                   </td>
               </tr>
           </table>
            
        </div>
        <?php
            }
            else{
                header("Location:index.php");
            }
        ?>
    </body>
</html>