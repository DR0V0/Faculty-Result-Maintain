<?php
    session_start();
?>
<html>
    <head>
        <title>Sign In</title>
    </head>
    <body>
       
       <?php
            
        $admin_id = "";
        $password = "";
        
        if($_SERVER['REQUEST_METHOD'] == "POST"){
            $admin_id = valid_the_input($_POST['admin_id']);
            $password = valid_the_input($_POST['password']);
                if($admin_id != null && $password != null){
                    if($admin_id == "mdh" && $password == "mdh"){
                        $_SESSION['admin_id'] = $admin_id;
                        header("Location:admin_home_page.php");
                    }
                    else{
                        echo("ID or PASSWORD NOT CORRECT!");
                    }
                }
        }
            
        function valid_the_input($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }
        ?>
       
        <form method="POST" action="">
            Enter ID: <input type="text" name="admin_id" placeholder="Enter ID"><br />
            Enter Password: <input type="password" name="password" placeholder="Enter Password"><br />
            <input type="submit" name="submit" value="Sign In" />
        </form>
    </body>
</html>