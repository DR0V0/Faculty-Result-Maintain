<html>
    <head>
        <title>Create Section</title>
    </head>
    <body>
       <?php
            //validing the inserted data
            function valid_the_input($data){
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
            }
        
            //creating the variables to intersert into the database
            $course_code = "";
            $section_number = "";
        
            //if submit button is pressed
            if($_SERVER['REQUEST_METHOD'] == "POST"){
                
                //inserting values into the variables
                $course_code = valid_the_input($_POST['course_code']);
                $section_number = valid_the_input($_POST['section_number']);
                
                if($course_code != "" && $section_number != ""){
                    $connection = mysqli_connect("localhost","root","","mdh");
                    
                    if($connection){
                        $my_first_qur = "INSERT INTO course_info(course_code,section_number) VALUES('$course_code','$section_number')";
                        $my_first_qur_insert = mysqli_query($connection,$my_first_qur);
                        
                        if($my_first_qur_insert){
                            $table_name = "$course_code'+'_'+'$section_number";
                            $my_second_qur = "CREATE TABLE '+$table_name+'(
                                        student_id VARCHAR(150),
                                        mid1 FLOAT,
                                        quiz1 FLOAT,
                                        mid2 FLOAT,
                                        quiz2 FLOAT,
                                        final FLOAT,
                                        quiz3 FLOAT
                                        )";
                            mysqli_query($connection,$my_second_qur);
                        }
                    }
                    else{
                        echo("NOT CONNECTED!");
                    }
                }
            }
        ?>
        <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
            Course Code:<input type="text" name="course_code" placeholder="Enter Course Code"><br />
            Section Number: <input type="text" name="section_number" placeholder="Enter Section Number"><br />
            <input type="submit" value="Create Section">
        </form>
    </body>
</html>