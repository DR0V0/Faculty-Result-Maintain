<?php
    session_start();
?>
<html>
    <head>
        <title>Add Section</title>
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>
    <body>
        <?php
            if(isset($_SESSION['admin_id'])){
        ?>
                <div class="head">
                    <div class="head_left_side">
                        <h1>Sir Here you can add section</h1>
                    </div>
                    <div class="head_right_side">
                        <table>
                            <tr>
                                <td>
                                    <a href="admin_home_page.php">
                                        <figure>
                                            <img src="back.png" alt="Back" height="50" width="50">
                                        </figure>
                                    </a>
                                </td>
                                <td>
                                    <a href="sign_out.php">
                                        <figure>
                                            <img src="logout.png" alt="Sign Out" height="50" width="50">
                                        </figure>
                                    </a>
                                </td>
                            </tr>
                        </table>
                       
                        
                    </div>
                </div>
                <?php
                    $conn = mysqli_connect("localhost","root","","mdh");
                    
                    $semester_name = "";
                    $course_code = "";
                    $section_number = "";
                    $section_name = "";
                    
                    if($_SERVER['REQUEST_METHOD'] == "POST"){
                        $semester_name = $_POST['semester_name'];
                        $course_code = $_POST['course_code'];
                        $section_number = $_POST['section_number'];
                        if(isset($_POST['submit'])){
                            if($semester_name != null && $course_code != null && $section_number != null){
                                if($conn){
                                    $my_first_qur = "SELECT * FROM classes_info WHERE semester_name = '$semester_name' AND course_code = '$course_code' AND section_number = '$section_number'";
                                    $my_first_qur_insert = mysqli_query($conn,$my_first_qur);
                                    if(mysqli_num_rows($my_first_qur_insert)>0){
                                        echo("THIS SECTION ALREADY INSERTED!");
                                    }
                                    else{
                                        $section_name = "$semester_name"."_$course_code"."_$section_number";
                                        $my_second_qur = "INSERT INTO classes_info(semester_name,course_code,section_number,section_name) VALUES('$semester_name','$course_code','$section_number','$section_name')";
                                        $my_second_qur_insert = mysqli_query($conn,$my_second_qur);
                                        if($my_second_qur_insert){
                                            $my_third_qur = "CREATE TABLE ".$section_name."(
                                                                    id VARCHAR(50),
                                                                    mid1 VARCHAR(50),
                                                                    mid2 VARCHAR(50),
                                                                    final VARCHAR(50),
                                                                    quiz1 VARCHAR(50),
                                                                    quiz2 VARCHAR(50),
                                                                    quiz3 VARCHAR(50),
                                                                    assignment1 VARCHAR(50),
                                                                    assignment2 VARCHAR(50),
                                                                    assignment3 VARCHAR(50)
                                                                )";
                                            
                                            mysqli_query($conn,$my_third_qur);
                                            header("Location:admin_home_page.php");
                                            
                                        }
                                        else{
                                            echo("NOT INSERTED!");
                                        }
                                    }
                                }
                                else{
                                    echo("NOT CONNECTED!");
                                }
                            }
                        }
                    }
                    
                    function valid_the_input($data){
                        $data = trim($data);
                        $data = stripslashes($data);
                        $data = htmlspecialchars($data);
                        return $data;
                    }
                ?>
                <div class="body">
                    <form method="POST" action="">
                        <select name="semester_name">
                            <option value="fall2018">fall2018</option> 
                        </select><br />
                        <select name="course_code">
                            <option value="cse101">CSE101</option>
                            <option value="cse480">CSE480</option>  
                        </select><br />
                        <select name="section_number">
                            <option value="1">1</option>
                            <option value="2">2</option>
                            <option value="8">8</option>
                            <option value="9">9</option> 
                        </select><br />
                        <input type="submit" name="submit" value="Add Section" />
                    </form>
                </div>
        <?php
            }
            else{
                header("Location:admin_login.php");
            }
        ?>
    </body>
</html>